package co.com.kantar.stepDefinitions;

import co.com.kantar.interaction.open_browser.OpenBrowser;
import co.com.kantar.tasks.authentication.Login;
import co.com.kantar.utils.transversal.CargarDatos;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.List;
import java.util.Map;

import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static co.com.kantar.utils.Constantes.NOMBRE_ACTOR;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class KantarStepDefinition {

    @Given("^that the user is on the principal page$")
    public void thatTheUserIsOnThePrincipalPage() {
        theActorCalled(NOMBRE_ACTOR).wasAbleTo(OpenBrowser.withUrl());
    }

    @When("^enter user and password$")
    public void enterUserAndPassword(List<Map<String, Object>> info) {
        theActorCalled(NOMBRE_ACTOR).attemptsTo(CargarDatos.conLaSiguiente(info),
                Login.onPage());
    }

    @Then("^will be able to see Welcome$")
    public void willBeAbleToSeeWelcome() {
    }

    @Given("^that the user is on countries$")
    public void thatTheUserIsOnCountries() {
    }


    @When("^enter code and name$")
    public void enterCodeAndName(List<Map<String, Object>> inforTwo) {

    }

    @Then("^will be able to see Country saved with success$")
    public void willBeAbleToSeeCountrySavedWithSuccess() {

    }

    @When("^user remove the country$")
    public void userRemoveTheCountry() {
    }

    @Then("^will be able to see Country deleted with success$")
    public void willBeAbleToSeeCountryDeletedWithSuccess() {

    }

}
