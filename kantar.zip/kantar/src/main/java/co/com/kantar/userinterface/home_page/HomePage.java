package co.com.kantar.userinterface.home_page;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class HomePage extends PageObject {
    public static final Target BTN_LOCATION =
            Target.the("button location").
                    locatedBy("//*[@id='left-panel']/nav/ul/li[1]");

    public static final Target BTN_COUNTRIES =
            Target.the("button countries").
                    locatedBy("//*[contains(text(),'Countries Registration')]");

    public static final Target BTN_ADD =
            Target.the("button add").
                    locatedBy("//*[@class='btn btn-default null ng-scope']");

    public static final Target BTN_OPTIONS =
            Target.the("button options").
                    locatedBy("//*[@class='{0}'][1]");

    public static final Target BTN_CONFIRM =
            Target.the("button confirm remove or no confirm remove").
                    locatedBy("//*[@id='{0}']");


    public static final Target LBL_CODE =
            Target.the("label code").
                    locatedBy("//*[@class='form-control editable-input']");

    public static final Target LBL_NAME =
            Target.the("label name").
                    locatedBy("//*[@id='s2id_autogen2']");

    public static final Target BTN_CSV =
            Target.the("button csv").
                    locatedBy("//*[@id='ToolTables_countryTable_0']");

    public static final Target TXT_SUCCESS =
            Target.the("texto confirm success").
                    locatedBy("//*[@class='fa fa-check']");



}
