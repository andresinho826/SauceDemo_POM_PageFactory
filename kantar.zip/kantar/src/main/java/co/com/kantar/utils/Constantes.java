package co.com.kantar.utils;

public class Constantes {

    public static final String NOMBRE_ACTOR = "Andres";
    public static final String BTN_EDIT = "fa fa-pencil";
    public static final String BTN_SAVE = "fa fa-save";
    public static final String BTN_REMOVE = "fa fa-trash-o";
    public static final String BTN_CONFIRM_REMOVE = "save_btn";
    public static final String BTN_NO_CONFIRM_REMOVE = "clear_upload_btn";

    private Constantes() {}
}
