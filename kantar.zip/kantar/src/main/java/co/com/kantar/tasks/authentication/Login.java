package co.com.kantar.tasks.authentication;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.waits.WaitUntil;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isEnabled;
import static co.com.kantar.userinterface.authentication.Authentication.*;
import static co.com.kantar.utils.transversal.DatosPrueba.*;

public class Login implements Task {
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitUntil.the(TXT_USER, isEnabled()).forNoMoreThan(30).seconds(),
                Click.on(TXT_USER),
                Enter.theValue(obtener("User")).into(TXT_USER),
                WaitUntil.the(TXT_PASS, isEnabled()).forNoMoreThan(10).seconds(),
                Click.on(TXT_PASS),
                Enter.theValue(obtener("Pass")).into(TXT_PASS),
                Click.on(BTN_CONNECT)
        );

    }
    public static Login onPage(){return Tasks.instrumented(Login.class);}
}
