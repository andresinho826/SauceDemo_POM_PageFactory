package co.com.kantar.userinterface.authentication;

import net.serenitybdd.screenplay.targets.Target;

public class Authentication {
    public static final Target TXT_USER =
            Target.the("enter user").
                    locatedBy("//*[@class='ng-dirty ng-valid ng-valid-required']");

    public static final Target TXT_PASS =
            Target.the("enter pass").
                    locatedBy("//*[@id='login-form']/fieldset/section[2]/label[2]/input");

    public static final Target BTN_CONNECT =
            Target.the("button connect").
                    locatedBy("//*[@class='btn btn-primary']");

    public static final Target TXT_WELCOME =
            Target.the("text welcome").
                    locatedBy("//p[contains(text(),'Welcome, ')]");
}
